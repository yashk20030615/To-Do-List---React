import { Index } from './Screen/home'
//import './App.css'
function App() {

  return (
    <>
      <Index />
    </>
  )
}

export default App
